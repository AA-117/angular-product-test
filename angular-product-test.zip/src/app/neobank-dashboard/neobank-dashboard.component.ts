import { Component } from '@angular/core';

@Component({
  selector: 'app-neobank-dashboard',
  standalone:false,
  templateUrl: './neobank-dashboard.component.html',
  styleUrl: './neobank-dashboard.component.css'
})
export class NeobankDashboardComponent {
  activeTab: string = 'transactions';

  setActiveTab(selectedInput:string) {
    this.activeTab = selectedInput;
  }
}
