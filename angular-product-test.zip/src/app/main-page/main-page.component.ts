import { Component } from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";
import {Chart, ChartConfiguration, ChartData, ChartType, registerables} from "chart.js/auto";

Chart.register(...registerables)

@Component({
  selector: 'app-main-page',
  standalone: false,
  templateUrl: './main-page.component.html',
  styleUrl: './main-page.component.css'
})
export class MainPageComponent {
  tabs = ['Category Management', 'Budget Management', 'Transaction Management', 'Transaction Chart'];
  activeTab = this.tabs[0];

  categories = [
    { name: 'Gastronomie'},
    { name: 'Elektronik'},
    { name: 'Gesundheit'},
    { name: 'Spenden'}
  ];

  budgets = this.categories.map(cat => ({ name: cat.name, presetBudget: 100, remainBudget:100, extraAllowed: 10 }));

  totalAmount = this.budgets.reduce((sum1, budget) => sum1 + budget.presetBudget, 0);
  remainAmount = this.budgets.reduce((sum2, budget) => sum2 + budget.remainBudget, 0);

  inputForm: FormGroup;
  budgetForm: FormGroup;
  categoryForm: FormGroup;
  transactions: { category: string; amount: number; date: string }[] = [];

  chart: any = [];
  // chart: any;

  colors: { [key: string]: string } = {
    Gastronomie: '#FF6384',
    Elektronik: '#36A2EB',
    Gesundheit: '#FFCE56',
    Spenden: '#4BC0C0'
  };

  constructor(private fb: FormBuilder) {
    this.inputForm = this.fb.group({
      value: [''],
      category: [''],
      date: ['']
    });

    this.budgetForm = this.fb.group({
      category: [''],
      budget: [''],
      extraAllowed: ['']
    });

    this.categoryForm = this.fb.group({
      name: ['']
    });
  }

  switchTab(tab: string): void {
    if(tab === 'Transaction Chart') {
      setTimeout(() => this.renderChart('doughnut'), 0);
    }
    this.activeTab = tab;
    this.totalAmount = this.budgets.reduce((sum1, bud) => sum1 + bud.presetBudget, 0);
    this.remainAmount = this.budgets.reduce((sum2, bud) => sum2 + bud.remainBudget, 0);
  }

  onAddCategory(): void {
    const { name } = this.categoryForm.value;
    if (name && !this.categories.some(cat => cat.name === name)) {
      this.categories.push({name});
      this.budgets.push({ name, presetBudget: 0, remainBudget: 0, extraAllowed: 0 });

      if (!this.colors[name]) {
        this.colors[name] = this.generateRandomColor();
      }
      this.categoryForm.reset();
    }
  }

  onRemoveCategory(categoryName: string): void {
    this.categories = this.categories.filter(cat => cat.name !== categoryName);
    this.budgets = this.budgets.filter(budget => budget.name !== categoryName);

    delete this.colors[categoryName];
  }

  onSetBudget(): void {
    const { category, budget, extraAllowed } = this.budgetForm.value;
    const budgetToUpdate = this.budgets.find(b => b.name === category);
    if (budgetToUpdate) {
      budgetToUpdate.presetBudget = parseFloat(budget);
      budgetToUpdate.remainBudget = budgetToUpdate.presetBudget;
      budgetToUpdate.extraAllowed = !!extraAllowed ? extraAllowed : 0;
      this.budgetForm.reset();
    }
  }

  onAddTransaction(): void {
    const { value, category, date } = this.inputForm.value;
    const amount = parseFloat(value);
    if (!isNaN(amount) && category && date) {
      const budgetToUpdate = this.budgets.find(bud => bud.name === category);
      if (budgetToUpdate) {
        if (budgetToUpdate.remainBudget -amount + budgetToUpdate.presetBudget * budgetToUpdate.extraAllowed / 100 > 0) {
          budgetToUpdate.remainBudget -= amount;
          this.transactions.push({category, amount, date});
          this.remainAmount = this.budgets.reduce((sum, bud) => sum + bud.remainBudget, 0);
        }
        else {
          alert("Transaction exceeds the allowed extra limit and therefore is aborted.");
        }
      }
      this.inputForm.reset();
    }
  }

  onDeleteTransaction(index: number): void {
    const transaction = this.transactions[index];
    const transactionToUpdate = this.budgets.find(bud => bud.name === transaction.category);
    if (transactionToUpdate) {
      transactionToUpdate.remainBudget += transaction.amount;
    }
    this.transactions.splice(index, 1);
    this.remainAmount = this.budgets.reduce((sum, bud) => sum + bud.remainBudget, 0);
  }

  renderChart(type: string): void {
    const canvas = document.getElementById('transactionChart') as HTMLCanvasElement;
    if(!canvas) return;
    const ctx = canvas.getContext('2d');
    if(!ctx) return;

    const categoryTotals = this.categories.map(cat => {
      const total = this.transactions
        .filter(transaction => transaction.category === cat.name)
        .reduce((sum, transaction) => sum + transaction.amount, 0);
      return { name: cat.name, total };
    });

    const data = {
      labels: categoryTotals.map(cat => cat.name),
      datasets: [
        {
          data: categoryTotals.map(cat => cat.total),
          label: 'Transaction Amount in Category',
          backgroundColor: categoryTotals.map(cat => this.colors[cat.name])
        }
      ]
    };

    if(this.chart instanceof Chart) {
      this.chart.destroy();
      this.chart = null;
    }

    if (type === 'doughnut') {
      const doughnutConfig: ChartConfiguration<'doughnut'> = {
        type: 'doughnut',
        data,
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'top'
            }
          }
        }
      };
      this.chart = new Chart(ctx, doughnutConfig);
    }

    if (type === 'bar') {
      const barConfig: ChartConfiguration<'bar'> = {
        type: 'bar',
        data,
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'top'
            }
          },
          scales: {
            x: {
              beginAtZero: true,
              ticks: {
                autoSkip: false, // Ensures labels are not skipped
                maxRotation: 45, // Adjust rotation for better visibility
                minRotation: 0
              },
              title: {
                display: true,
                text: 'Categories' // Add a title to the X-axis
              }
            },
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: 'Amount (€)' // Add a title to the Y-axis
              }
            }
          }
        }
      };
      this.chart = new Chart(ctx, barConfig);
    }
  }

  private generateRandomColor(): string {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
  }
}
