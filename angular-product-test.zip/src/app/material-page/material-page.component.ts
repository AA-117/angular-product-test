import { Component } from '@angular/core';

@Component({
  selector: 'app-material-page',
  standalone: false,
  templateUrl: './material-page.component.html',
  styleUrl: './material-page.component.css'
})
export class MaterialPageComponent {

}
